import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import accuracy_score, classification_report
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import LabelEncoder, StandardScaler
import joblib

# Charger les données
data_train = pd.read_csv("C:/Users/aimen/Downloads/KDDTrain+.txt")

# Renommer les colonnes
columns = ['duration', 'protocol_type', 'service', 'flag', 'src_bytes', 'dst_bytes', 'land', 'wrong_fragment', 'urgent',
           'hot', 'num_failed_logins', 'logged_in', 'num_compromised', 'root_shell', 'su_attempted', 'num_root',
           'num_file_creations', 'num_shells', 'num_access_files', 'num_outbound_cmds', 'is_host_login',
           'is_guest_login', 'count', 'srv_count', 'serror_rate', 'srv_serror_rate', 'rerror_rate', 'srv_rerror_rate',
           'same_srv_rate', 'diff_srv_rate', 'srv_diff_host_rate', 'dst_host_count', 'dst_host_srv_count',
           'dst_host_same_srv_rate', 'dst_host_diff_srv_rate', 'dst_host_same_src_port_rate',
           'dst_host_srv_diff_host_rate', 'dst_host_serror_rate', 'dst_host_srv_serror_rate', 'dst_host_rerror_rate',
           'dst_host_srv_rerror_rate', 'label', 'level']

data_train.columns = columns

# Encoder les étiquettes
data_train['label'] = data_train['label'].apply(lambda x: 'normal' if x == 'normal' else 'attack')

# Encoder les variables catégorielles
encoder_protocol = LabelEncoder()
data_train['protocol_type'] = encoder_protocol.fit_transform(data_train['protocol_type'])

encoder_service = LabelEncoder()
data_train['service'] = encoder_service.fit_transform(data_train['service'])

encoder_flag = LabelEncoder()
data_train['flag'] = encoder_flag.fit_transform(data_train['flag'])

# Sauvegarder les encodeurs
joblib.dump(encoder_protocol, 'protocol_type_encoder.joblib')
joblib.dump(encoder_service, 'service_encoder.joblib')
joblib.dump(encoder_flag, 'flag_encoder.joblib')

# Sélectionner les colonnes pertinentes
selected_columns = ['duration', 'protocol_type', 'service', 'flag', 'src_bytes', 'dst_bytes', 'land', 'wrong_fragment', 'urgent',
                    'hot', 'num_failed_logins', 'logged_in', 'num_compromised', 'root_shell', 'su_attempted', 'num_root',
                    'num_file_creations', 'num_shells', 'num_access_files', 'num_outbound_cmds', 'is_host_login',
                    'is_guest_login', 'count', 'srv_count', 'serror_rate', 'srv_serror_rate', 'rerror_rate', 'srv_rerror_rate',
                    'same_srv_rate', 'diff_srv_rate', 'srv_diff_host_rate', 'dst_host_count', 'dst_host_srv_count',
                    'dst_host_same_srv_rate', 'dst_host_diff_srv_rate', 'dst_host_same_src_port_rate',
                    'dst_host_srv_diff_host_rate', 'dst_host_serror_rate', 'dst_host_srv_serror_rate', 'dst_host_rerror_rate',
                    'dst_host_srv_rerror_rate']

X = data_train[selected_columns]
encoder_label = LabelEncoder()
y_classification = encoder_label.fit_transform(data_train['label'])

# Diviser les données en ensembles d'entraînement et de test
x_train, x_test, y_train, y_test = train_test_split(X, y_classification, test_size=0.2, random_state=42)

# Normaliser les données
scaler = StandardScaler()
x_train_scaled = scaler.fit_transform(x_train)
x_test_scaled = scaler.transform(x_test)

# Créer et entraîner le classificateur avec validation croisée
clf = DecisionTreeClassifier(random_state=42)
scores = cross_val_score(clf, x_train_scaled, y_train, cv=5)
print(f"Validation croisée (accuracy): {scores.mean()}")

clf.fit(x_train_scaled, y_train)

# Évaluer le classificateur
y_pred = clf.predict(x_test_scaled)
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy}")
print(classification_report(y_test, y_pred, target_names=['normal', 'attack']))

# Sauvegarder le modèle et le scaler
joblib.dump(clf, 'modele_decision_tree.joblib')
joblib.dump(scaler, 'scaler.joblib')

# Charger le modèle et le scaler
modele = joblib.load('modele_decision_tree.joblib')
scaler = joblib.load('scaler.joblib')
encoder_protocol = joblib.load('protocol_type_encoder.joblib')
encoder_service = joblib.load('service_encoder.joblib')
encoder_flag = joblib.load('flag_encoder.joblib')

# Fonction de prédiction
def predire_attaque(nouvelle_donnee):
    # Colonnes pertinentes
    selected_columns = ['duration', 'protocol_type', 'service', 'flag', 'src_bytes', 'dst_bytes', 'land', 'wrong_fragment', 'urgent',
                    'hot', 'num_failed_logins', 'logged_in', 'num_compromised', 'root_shell', 'su_attempted', 'num_root',
                    'num_file_creations', 'num_shells', 'num_access_files', 'num_outbound_cmds', 'is_host_login',
                    'is_guest_login', 'count', 'srv_count', 'serror_rate', 'srv_serror_rate', 'rerror_rate', 'srv_rerror_rate',
                    'same_srv_rate', 'diff_srv_rate', 'srv_diff_host_rate', 'dst_host_count', 'dst_host_srv_count',
                    'dst_host_same_srv_rate', 'dst_host_diff_srv_rate', 'dst_host_same_src_port_rate',
                    'dst_host_srv_diff_host_rate', 'dst_host_serror_rate', 'dst_host_srv_serror_rate', 'dst_host_rerror_rate',
                    'dst_host_srv_rerror_rate']

    # Créer un DataFrame avec la nouvelle donnée
    nouvelle_donnee_df = pd.DataFrame([nouvelle_donnee], columns=selected_columns)
    
    # Encoder les variables catégorielles
    nouvelle_donnee_df['protocol_type'] = encoder_protocol.transform(nouvelle_donnee_df['protocol_type'])
    nouvelle_donnee_df['service'] = encoder_service.transform(nouvelle_donnee_df['service'])
    nouvelle_donnee_df['flag'] = encoder_flag.transform(nouvelle_donnee_df['flag'])
    
    # Mettre à l'échelle les données
    nouvelle_donnee_scaled = scaler.transform(nouvelle_donnee_df)
    
    # Faire la prédiction
    prediction = modele.predict(nouvelle_donnee_scaled)
    
    return encoder_label.inverse_transform([prediction[0]])[0]

# Exemple d'utilisation
#nouvelle_donnee = [0,'tcp','http','SF',287,2251,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,3,7,0.00,0.00,0.00,0.00,1.00,0.00,0.43,8,219,1.00,0.00,0.12,0.03,0.00,0.00,0.00,0.00]
nouvelle_donnee =[37,'tcp','telnet','SF',773,364200,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,1,1,0.00,0.00,0.00,0.00,1.00,0.00,0.00,38,73,0.16,0.05,0.03,0.04,0.00,0.77,0.00,0.07]
prediction = predire_attaque(nouvelle_donnee)
print("Prédiction :", prediction)
