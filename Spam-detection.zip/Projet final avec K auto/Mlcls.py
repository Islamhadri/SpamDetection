import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
from sklearn.metrics.pairwise import cosine_similarity, euclidean_distances
import tkinter as tk
from tkinter import scrolledtext, font, messagebox
from PIL import Image, ImageTk
import datetime
import matplotlib.pyplot as plt

#IFKNN(Improved Fuzzy KNN) model: 
class IFuzzyKNN(BaseEstimator, ClassifierMixin):

    def __init__(self, k=3, distance_metric='euclidean'):
        self.k = k
        self.distance_metric = distance_metric
        self.fitted_ = None

    def fit(self, X, y=None):
        self.X_train = X
        self.y_train = np.array(y).reshape(-1)  # Ensure y_train is 1D array
        self.classes = np.unique(y)
        self.fitted_ = True
        return self

    def predict(self, X):
        if self.fitted_ is None:
            raise Exception('predict() called before fit()')
        else:
            y_pred = []
            if self.distance_metric == 'cosine':
                similarities = cosine_similarity(X, self.X_train)
            elif self.distance_metric == 'euclidean':
                similarities = 1 / (1 + euclidean_distances(X, self.X_train))
            else:
                raise ValueError("Invalid distance metric. Choose 'cosine' or 'euclidean'.")
            for sim in similarities:
                nearest_indices = np.argsort(sim)[-self.k:]
                nearest_labels = self.y_train[nearest_indices]
                label_counts = [np.sum(nearest_labels == c) for c in self.classes]
                pred_label = self.classes[np.argmax(label_counts)]
                y_pred.append(pred_label)
            return y_pred

    def get_memberships(self, X):
        memberships = []
        if self.distance_metric == 'cosine':
            similarities = cosine_similarity(X, self.X_train)
        elif self.distance_metric == 'euclidean':
            similarities = 1 / (1 + euclidean_distances(X, self.X_train))
        else:
            raise ValueError("Invalid distance metric. Choose 'cosine' or 'euclidean'.")
        for sim in similarities:
            nearest_indices = np.argsort(sim)[-self.k:]
            nearest_labels = self.y_train[nearest_indices]
            membership = {}
            for c in self.classes:
                uci = np.sum(nearest_labels == c) / self.k
                membership[c] = uci
            memberships.append(membership)
        return memberships

#Evaluation Perfermance IFKNN:     
def compute_average_accuracy(classifier, X_train, X_test, y_train, y_test, n_runs=10):
    accuracies = []
    precisions = []
    recalls = []
    f1_scores = []
    macro_f1_scores = []
    for _ in range(n_runs):
        classifier.fit(X_train, y_train)
        y_pred = classifier.predict(X_test)
        accuracies.append(accuracy_score(y_test, y_pred))
        precisions.append(precision_score(y_test, y_pred, average='weighted'))
        recalls.append(recall_score(y_test, y_pred, average='weighted'))
        f1_scores.append(f1_score(y_test, y_pred, average='weighted'))
        macro_f1_scores.append(f1_score(y_test, y_pred, average='macro'))
    return {
        'accuracy': (np.mean(accuracies), np.std(accuracies)),
        'precision': (np.mean(precisions), np.std(precisions)),
        'recall': (np.mean(recalls), np.std(recalls)),
        'f1': (np.mean(f1_scores), np.std(f1_scores)),
        'macro_f1': (np.mean(macro_f1_scores), np.std(macro_f1_scores))
    }

#Read Dataset 
data = pd.read_csv("C:/Users/aimen/Desktop/Mémoire PFE/Application/Projet final/Projet final avec K auto/Dataset/emails.csv")

#preprocessing
def preprocess_text(text):
    text = text.lower().strip()
    text = "".join([char for char in text if char.isalnum() or char.isspace()])
    stop_words = set(stopwords.words("english"))
    words = word_tokenize(text)
    words = [word for word in words if word not in stop_words]
    ps = PorterStemmer()
    words = [ps.stem(word) for word in words]
    return " ".join(words)

#preprocessing DataSet
data["text"] = data["text"].apply(preprocess_text)

# Extraction Feature TF-IDF
vectorizer = TfidfVectorizer(max_features=3500)
features = vectorizer.fit_transform(data["text"])

#test - Split
X_train, X_test, y_train, y_test = train_test_split(features, data["spam"], test_size=0.2, stratify=data["spam"])

#training Model IFKNN
fuzzy_knn_euclidean = IFuzzyKNN(k=100, distance_metric='euclidean')
fuzzy_knn_euclidean.fit(X_train, y_train)
fuzzy_knn_euclidean_extracted = None

#Accuracy
metrics = compute_average_accuracy(fuzzy_knn_euclidean, X_train, X_test, y_train, y_test, n_runs=10)
#test New Message 
# Define the required functions
metrics_after_extraction = None

def test_new_email(email_text):
    email_features = vectorizer.transform([preprocess_text(email_text)])
    prediction = fuzzy_knn_euclidean.predict(email_features)
    memberships = fuzzy_knn_euclidean.get_memberships(email_features)
    result_str = ""
    if prediction[0] == 1:
        result_str += f"This email is: {email_text}  Spam\n"
    else:
        result_str += f"This email is: {email_text} not Spam\n"
    result_str += "Membership degrees:\n"
    for membership in memberships:
        result_str += str(membership) + "\n"
    y_pred_before_extraction = fuzzy_knn_euclidean.predict(X_test)
    accuracy_before_extraction = accuracy_score(y_test, y_pred_before_extraction)
    result_str += f"Accuracy before extraction (k=100): {accuracy_before_extraction:.4f}\n"
    return result_str, memberships, accuracy_before_extraction

def find_best_k(email_features, memberships_extracted):
    best_k = None
    best_diff = float('inf')
    best_memberships = None

    for k in range(1, 31):
        fknn = IFuzzyKNN(k=k, distance_metric='euclidean')
        fknn.fit(X_train, y_train)
        predicted = fknn.predict(email_features)
        memberships = fknn.get_memberships(email_features)
        spam_membership = memberships[0][1]
        non_spam_membership = memberships[0][0]
        membership_diff = abs(spam_membership - non_spam_membership)

        if membership_diff < best_diff:
            best_diff = membership_diff
            best_k = k
            best_memberships = memberships

    memberships_extracted[:] = best_memberships
    return best_k

def plot_accuracies(accuracy_before_extraction, accuracy_after_extraction=None, best_k=None):
    k_values = list(range(1, 31))
    accuracy_after = [None] * len(k_values)
    
    if accuracy_after_extraction is not None and best_k is not None:
        accuracy_after[best_k - 1] = accuracy_after_extraction

    plt.figure(figsize=(10, 6))
    plt.scatter([100], [accuracy_before_extraction], color='blue', label='Accuracy Before Extraction (k=100)')
    if accuracy_after_extraction is not None and best_k is not None:
        plt.scatter([best_k], [accuracy_after_extraction], color='red', label=f'Accuracy After Extraction (k={best_k})')
        plt.plot([100, best_k], [accuracy_before_extraction, accuracy_after_extraction], linestyle='--', color='grey')
        plt.text(100, accuracy_before_extraction, f'{accuracy_before_extraction:.4f}', ha='right', va='bottom', color='blue')
        plt.text(best_k, accuracy_after_extraction, f'{accuracy_after_extraction:.4f}', ha='right', va='bottom', color='red')

    if accuracy_after_extraction is not None:
        plt.plot(k_values, accuracy_after, linestyle='-', marker='o', color='red')

    plt.xlabel('k values')
    plt.ylabel('Accuracy')
    plt.ylim(0.94, 1)
    plt.title('Accuracy Before and After Extraction for Different k values')
    plt.legend()
    plt.grid(True)
    plt.show()

def extract_message(email_text, accuracy_before_extraction):
    global fuzzy_knn_euclidean_extracted
    global metrics_after_extraction
    email_features = vectorizer.transform([preprocess_text(email_text)])
    prediction = fuzzy_knn_euclidean.predict(email_features)
    memberships = fuzzy_knn_euclidean.get_memberships(email_features)
    spam_membership = memberships[0][1]
    non_spam_membership = memberships[0][0]
    membership_diff = abs(spam_membership - non_spam_membership)
    output_text = f"Message: {email_text}\n"
    accuracy_after_extraction = None
    best_k = None
    if membership_diff <= 0.2:
        output_text += f"The difference between the membership degrees for spam and non-spam is {membership_diff:.12f}. This message will be extracted.\n"
        best_k = find_best_k(email_features, memberships)
        if fuzzy_knn_euclidean_extracted is None:
            fuzzy_knn_euclidean_extracted = IFuzzyKNN(k=best_k, distance_metric='euclidean')
            fuzzy_knn_euclidean_extracted.fit(X_train, y_train)
        output_text += f"\nThe result of Improved FuzzyKNN (IFKNN) with k={best_k} and euclidean distance:\n"
        prediction_extracted = fuzzy_knn_euclidean_extracted.predict(email_features)
        if prediction_extracted[0] == 1:
            output_text += f"This email is: Spam\n"
        else:
            output_text += f"This email is: not Spam\n"
        output_text += "New membership degrees:\n"
        for membership in memberships:
            output_text += str(membership) + "\n"
        y_pred_after_extraction = fuzzy_knn_euclidean_extracted.predict(X_test)
        accuracy_after_extraction = accuracy_score(y_test, y_pred_after_extraction)
        output_text += f"Accuracy after extraction (k={best_k}): {accuracy_after_extraction:.4f}\n"
        output_text += "-" * 30 + "\n"
        recall_after_extraction = recall_score(y_test, y_pred_after_extraction, average='weighted')
        metrics_after_extraction = compute_average_accuracy(fuzzy_knn_euclidean_extracted, X_train, X_test, y_train, y_test, n_runs=10)

    else:
        output_text += f"The difference between the membership degrees for spam and non-spam is {membership_diff:.12f}. This message will not be extracted.\n"
        output_text += "-" * 30 + "\n"
    result_text.insert(tk.END, output_text)
    return accuracy_after_extraction, best_k

def test_email():
    email_text = input_text.get("1.0", "end-1c").strip()
    if email_text == "":
        result_text.delete("1.0", tk.END)
        result_text.insert(tk.END, "Please enter an email before testing.")
        return

    result_text.delete("1.0", tk.END)
    
    # Test new email and display the results
    email_result, memberships, accuracy_before_extraction = test_new_email(email_text)
    result_text.insert(tk.END, email_result)

    # Extract message and get updated accuracy
    accuracy_after_extraction, best_k = extract_message(email_text, accuracy_before_extraction)

    # Display Metrics in the Evaluation Space
    eval_text.delete("1.0", tk.END)
    eval_text.insert(tk.END, f"Evaluation Before extraction\n")
    eval_text.insert(tk.END, f"Mean Accuracy: {metrics['accuracy'][0]:.4f} \n")
    eval_text.insert(tk.END, f"Precision: {metrics['precision'][0]:.4f}\n")
    eval_text.insert(tk.END, f"Recall: {metrics['recall'][0]:.4f} \n")
    eval_text.insert(tk.END, f"F1 Score: {metrics['f1'][0]:.4f} \n")
    eval_text.insert(tk.END, f"Macro F1 Score: {metrics['macro_f1'][0]:.4f} \n")
    if accuracy_after_extraction and metrics_after_extraction:
        eval_text.insert(tk.END, f"Evaluation After extraction:\n")
        eval_text.insert(tk.END, f"Mean Accuracy after extraction: {metrics_after_extraction['accuracy'][0]:.4f}\n")
        eval_text.insert(tk.END, f"Precision after extraction: {metrics_after_extraction['precision'][0]:.4f}\n")
        eval_text.insert(tk.END, f"Recall after extraction: {metrics_after_extraction['recall'][0]:.4f} \n")
        eval_text.insert(tk.END, f"F1 Score after extraction: {metrics_after_extraction['f1'][0]:.4f} \n")
        eval_text.insert(tk.END, f"Macro F1 Score after extraction: {metrics_after_extraction['macro_f1'][0]:.4f} \n")

    # Plot the accuracies
    plot_accuracies(accuracy_before_extraction, accuracy_after_extraction, best_k)


    
# Function to Export an Unwanted Message (Spam)
def export_spam_email():
    email_text = input_text.get("1.0", "end-1c").strip()
    if email_text == "":
        result_text.delete("1.0", tk.END)
        result_text.insert(tk.END, "Please enter an email before exporting.")
        return
    # Check if the Message is Already Present in the File SpamBox.txt
    with open("C:/Users/aimen/Desktop/Mémoire PFE/Application/Projet final/Projet final avec K auto/Spambox.txt", "r", encoding="utf-8") as spam_box_file:
        existing_messages = spam_box_file.read()
        if email_text in existing_messages:
            result_text.delete("1.0", tk.END)
            result_text.insert(tk.END, "This email is already in the SpamBox.")
            return
    email_features = vectorizer.transform([preprocess_text(email_text)])
    prediction = fuzzy_knn_euclidean.predict(email_features)
    if prediction[0] == 1:
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open("C:/Users/aimen/Desktop/Mémoire PFE/Application/Projet final/Projet final avec K auto/Spambox.txt", "a", encoding="utf-8") as spam_box_file:
            spam_box_file.write(f"{timestamp} - {email_text}\n\n")
            spam_box_file.flush()  # Ensure the Data is Written Immediately to the File
        result_text.delete("1.0", tk.END)
        result_text.insert(tk.END, f"The following email has been exported to SpamBox.txt:\n{email_text}")
    else:
        result_text.delete("1.0", tk.END)
        result_text.insert(tk.END, "This email is not spam and will not be exported.")

#Function to Display the Spam Inbox
def show_spam_box():
    try:
        with open("C:/Users/aimen/Desktop/Mémoire PFE/Application/Projet final/Projet final avec K auto/Spambox.txt", "r", encoding="utf-8") as spam_box_file:
            spam_content = spam_box_file.read()
            if spam_content.strip() == "":
                messagebox.showinfo("SpamBox", "SpamBox is empty!")
            else:
                root.iconbitmap ("C:/Users/aimen/Desktop/Mémoire PFE/Application/Projet final/Projet final avec K auto/1.ico")
                spam_box_window = tk.Toplevel(root)
                spam_box_window.title("Application Spam Email Detector - SpamBox")  
                spam_box_window.geometry("1080x720") 
                spam_image = Image.open("C:/Users/aimen/Desktop/Mémoire PFE/Application/mo.jpg")
                spam_image = spam_image.resize((500, 700))  
                spam_photo = ImageTk.PhotoImage(spam_image)
                spam_image_label = tk.Label(spam_box_window, image=spam_photo, bg="white")
                spam_image_label.image = spam_photo  
                spam_image_label.pack(side="left", padx=20, pady=10,anchor="w")  
                spam_text_frame = tk.Frame(spam_box_window, bg="white")  
                spam_text_frame.pack(fill="both", expand=True, padx=20, pady=10)  
                spam_label = tk.Label(spam_text_frame, text="SpamBox :", font=label_font, bg="#FFFFFF")
                spam_label.pack()
                spam_text = scrolledtext.ScrolledText(spam_text_frame, width=40, height=20, font=label_font, bg="white", fg="black")
                spam_text.pack(fill="both", expand=True)
                spam_text.insert(tk.END, spam_content)
                spam_text.config(state="disabled")
    except FileNotFoundError:
        messagebox.showerror("Error", "SpamBox.txt not found!")

def close_application():
    export_spam_email()  
    root.destroy()  
def clear_fields():
    input_text.delete("1.0", tk.END)
    eval_text.delete("1.0", tk.END)
    result_text.delete("1.0", tk.END)

root = tk.Tk()
root.title("Application for Spam Email Detector")
root.geometry("1080x720")
root.minsize(480, 360)
root.iconbitmap("C:/Users/aimen/Desktop/Mémoire PFE/Application/Projet final/Projet final avec K auto/1.ico")
root.configure(bg="white")

title_font = font.Font(family="Arial", size=15, weight="bold")
label_font = font.Font(family="Arial", size=12)
button_font = font.Font(family="Arial", size=10)

title_frame = tk.Frame(root, bg="#4287f5", pady=30)
title_frame.pack(fill="x", pady=6, side="top")
title_label = tk.Label(title_frame, text="Application for Spam Email Detector", fg="white", bg="#4287f5", font=title_font)
title_label.pack()

logo_img = Image.open("C:/Users/aimen/Desktop/Mémoire PFE/Application/Projet final/Projet final avec K auto/mohcene.png")
logo_img = logo_img.resize((500, 680))
logo_photo = ImageTk.PhotoImage(logo_img)

logo_frame = tk.Frame(root, bg="#F0F0F0")
logo_frame.pack(side="left", padx=6, pady=6)
logo_label = tk.Label(logo_frame, image=logo_photo, bg="#F0F0F0")
logo_label.pack()

separator_vertical = tk.Canvas(root, width=2, height=680, bd=0, highlightthickness=0, bg="#4287f5")
separator_vertical.pack(side="left", fill="y", padx=6)

main_frame = tk.Frame(root, bg="#FFFFFF")
main_frame.pack(padx=20, pady=10, anchor="w", fill="both", expand=True)

text_frame = tk.Frame(main_frame, bg="#FFFFFF")
text_frame.pack(side="left", padx=10, pady=10, anchor="n")

input_label = tk.Label(text_frame, text="Enter your e-mail :", font=label_font, bg="#FFFFFF")
input_label.pack(anchor="w")
input_text = scrolledtext.ScrolledText(text_frame, width=50, height=4.5, font=label_font, bg="white", fg="black")
input_text.pack()

eval_label = tk.Label(text_frame, text="Evaluation :", font=label_font, bg="#FFFFFF", padx=10)
eval_label.pack(anchor="w")
eval_text = scrolledtext.ScrolledText(text_frame, width=50, height=6, font=label_font, bg="white", fg="black")
eval_text.pack()

info_frame = tk.Frame(main_frame, bg="#FFFFFF", pady=10)
info_frame.pack(side="left", padx=10, pady=10, anchor="n")

info_label = tk.Label(info_frame, text="How to use this application:", font=label_font, bg="#FFFFFF")
info_label.pack(anchor="w")
info_text = tk.Label(info_frame, text="1. Enter your email in the provided text box.\n2. Click 'Test and Extract Email' to analyze.\n3. Check the evaluation and result sections for details.\n4. Use 'SpamBox' to view detected spam emails.\n5. Click 'Export Spam' to save spam emails.\n6. Click 'Exit' to close the application.", font=label_font, bg="#FFFFFF", justify="left")
info_text.pack(anchor="w")

separator = tk.Canvas(root, height=2, bd=0, highlightthickness=0, bg="#4287f5")
separator.pack(fill="x", padx=20, pady=10)

result_frame = tk.Frame(root, bg="#FFFFFF", pady=10)
result_frame.pack(padx=20, pady=10, anchor="w")
result_label = tk.Label(result_frame, text="Result :", font=label_font, bg="#FFFFFF")
result_label.pack(anchor="w")
result_text = scrolledtext.ScrolledText(result_frame, width=100, height=11, font=label_font, bg="white", fg="black")
result_text.pack()

button_frame = tk.Frame(root, bg="#F0F0F0", pady=10)
button_frame.pack(pady=10)

custom_button = tk.Button(button_frame, text="Test and Extract Email", command=test_email, font=button_font, bg="#4287f5", fg="white", bd=0, padx=10, pady=5)
custom_button.pack(side="left", padx=10)

export_button = tk.Button(button_frame, text="Export Spam", command=export_spam_email, font=button_font, bg="#4287f5", fg="white", bd=0, padx=10, pady=5)
export_button.pack(side="left", padx=10)

spam_box_button = tk.Button(button_frame, text="SpamBox", command=show_spam_box, font=button_font, bg="#4F92FF", fg="white", bd=0, padx=10, pady=5)
spam_box_button.pack(side="left", padx=10)
#clear test/Evaluation/Result 
clear_button = tk.Button(button_frame, text="Clear", command=clear_fields, font=button_font, bg="#4F92FF", fg="white", bd=0, padx=10, pady=5)
clear_button.pack(side="left", padx=10)
exit_button = tk.Button(button_frame, text="Exit", command=close_application, font=button_font, bg="red", fg="white", bd=0, padx=10, pady=5)
exit_button.pack(side="left", padx=10)

root.mainloop() 